# Load required packages -----------------------------------------------------
library(mvtnorm)     # For multivariate normal distributions
library(R2WinBUGS)   # Interface between R and WinBUGS

# Data Preparation -----------------------------------------------------------
N <- 27  # Number of subjects/groups

# Read headache data with column names
headache <- read.table("headache.txt", col.names = c("d", "y", "x", "NT"))
attach(headache)

# Reshape data into matrices for WinBUGS compatibility
x <- matrix(x, byrow = TRUE, ncol = 5)  # 27x5 matrix for covariate x
d <- matrix(d, byrow = TRUE, ncol = 5)  # 27x5 matrix for dose variable d
y <- matrix(y, byrow = TRUE, ncol = 5)  # 27x5 matrix for outcome y

# Model 1: Poisson GLMM (Mixed Effects Model) --------------------------------
parameters <- c("beta", "sgm")  # Parameters to monitor

# Initial values for two chains
init1 <- list(beta = rep(-1, 2), psi = 1)
init2 <- list(beta = rep(1, 2), psi = 2)
inits <- list(init1, init2)

# Data list for WinBUGS
data <- list(N = N, NT = NT, x = x, d = d, y = y)

# Define WinBUGS model -------------------------------------------------------
glmmp_model <- function() {
  # Loop over each individual
  for(i in 1:N) {
    # Loop over each time point for the individual
    for(t in 1:NT[i]) {
      # Calculate the mean (mu) for the Poisson distribution
      mu[i,t] <- exp(beta[1] + beta[2] * x[i,t] + u[i]) * d[i,t]
      # Define the outcome variable y as following a Poisson distribution
      y[i,t] ~ dpois(mu[i,t])
    } # end of time point loop
    
    # Define the random effect u for each individual
    u[i] ~ dnorm(0, psi)
    
  } # end of individual loop
  
  # Prior distribution for the precision parameter psi
  psi ~ dgamma(9, 4)
  # Convert precision to standard deviation
  sgm <- 1 / psi
  
  # Prior distributions for the regression coefficients (beta)
  for(j in 1:2) {
    beta[j] ~ dnorm(0, 0.01)
  } # end of beta loop
}

# Run GLMM model
model1<-bugs(data,inits,parameters, model.file=glmmp_model,
             n.chains=2,n.iter=8000,n.burnin=3000,n.thin=1,
             bugs.directory="D:/WinBUGS14/",
             working.directory=getwd(),
             debug=FALSE) # You can change it to TRUE to see details

# Extract results for GLMM
Ebeta1 <- model1$mean$beta    # Posterior means of beta
SEbeta1 <- model1$sd$beta     # Posterior standard deviations
Esgm1 <- model1$mean$sgm      # Posterior mean of random effects SD
SEsgm1 <- model1$sd$sgm       # Posterior SD of random effects SD

# Model 2: Standard Poisson GLM (Fixed Effects Only) -------------------------
parametersg <- c("beta")       # Only monitor fixed effects

# Initial values for two chains
initg1 <- list(beta = rep(-1, 2))
initg2 <- list(beta = rep(1, 2))
initg <- list(initg1, initg2)

# Define the generalized linear model function --------------------------------
glm_model <- function() {
  # Loop over individuals
  for(i in 1:N) {
    # Loop over time points for each individual
    for(t in 1:NT[i]) {
      # Calculate mean for Poisson distribution
      mu[i,t] <- exp(beta[1] + beta[2] * x[i,t]) * d[i,t]
      # Define outcome variable y
      y[i,t] ~ dpois(mu[i,t])
    } # end of time loop
    
  } # end of individual loop
  
  # Prior distributions for regression coefficients
  for(j in 1:2) {
    beta[j] ~ dnorm(0, 10)  # Normal prior with mean 0 and precision 10
  } # end of beta loop
}

# Run GLM model
model2 <- bugs(data, initg, parametersg, 
               model.file = glm_model,
               n.chains = 2,
               n.iter = 8000,
               n.burnin = 3000,
               n.thin = 1,
               bugs.directory = "D:/WinBUGS14/",
               working.directory = getwd(),
               debug = FALSE)    

# Extract results for GLM
Ebeta3 <- model2$mean$beta     # Posterior means of beta
SEbeta3 <- model2$sd$beta      # Posterior standard deviations

# Results Presentation -------------------------------------------------------
cat("\n=== Model Comparison Results ===\n")

# Create comparison table
results_table <- data.frame(
  Model = rep(c("GLMM", "GLM"), each = 2),
  Parameter = rep(c("beta1", "beta2"), 2),
  Estimate = c(Ebeta1, Ebeta3),
  SE = c(SEbeta1, SEbeta3)
)

# Add random effects parameter for GLMM
random_effects_row <- data.frame(
  Model = "GLMM",
  Parameter = "sgm",
  Estimate = Esgm1,
  SE = SEsgm1
)

# Combine tables
full_results <- rbind(results_table, random_effects_row)

# Print formatted table
print(full_results, row.names = FALSE)

cat("\nKey Findings:")
cat("\n1. Random effects standard deviation (sgm):", 
    round(Esgm1, 3), "(SE:", round(SEsgm1, 3), ")")
cat("\n2. Between-model beta differences:")
cat("\n   beta1 difference:", round(abs(Ebeta1[1] - Ebeta3[1]), 3))
cat("\n   beta2 difference:", round(abs(Ebeta1[2] - Ebeta3[2]), 3))

# Model Comparison ----------------------------------------------------------

# 1. Extract Deviance Information Criterion (DIC)
cat("\n=== Model Comparison Criteria ===\n")
cat("GLMM DIC:", model1$DIC, "\n")
cat("GLM DIC :", model2$DIC, "\n")

# 2. Calculate Bayes Factor (if models are nested)
log_bf <- model1$pD - model2$pD  # Simple approximation
cat("\nApproximate log Bayes Factor:", round(log_bf, 3))

# 3. Create Comparison Table
results_table <- data.frame(
  Model = c("Poisson GLMM", "Poisson GLM"),
  DIC = c(model1$DIC, model2$DIC),
  pD = c(model1$pD, model2$pD),
  Beta1_Est = c(Ebeta1[1], Ebeta3[1]),
  Beta1_SE = c(SEbeta1[1], SEbeta3[1]),
  Beta2_Est = c(Ebeta1[2], Ebeta3[2]),
  Beta2_SE = c(SEbeta1[2], SEbeta3[2]),
  SD_Random = c(Esgm1, NA)  # NA for GLM
)

# 4. Format and Print Results
print(results_table, row.names = FALSE, digits = 3)

# 5. Visualization
par(mfrow = c(1,2))
plot(density(model1$sims.list$beta[,1]), main = "Beta1 Posterior", col="blue")
lines(density(model2$sims.list$beta[,1]), col="red")
legend("topright", legend = c("GLMM","GLM"), fill = c("blue","red"))

plot(density(model1$sims.list$beta[,2]), main = "Beta2 Posterior", col="blue")
lines(density(model2$sims.list$beta[,2]), col="red")

