# Load required packages
library(R2WinBUGS)

# Generate simulated data ----------------------------------------------------
set.seed(123)  # For reproducibility
n <- 300       # Sample size
true_beta <- c(0.5, 1, -1)  # True parameter values

# Generate covariates
x1 <- rnorm(n)
x2 <- rnorm(n)

# Calculate linear predictor and generate outcomes
linear_predictor <- true_beta[1] + true_beta[2]*x1 + true_beta[3]*x2
mu <- exp(linear_predictor)
y <- rpois(n, lambda = mu)

# Define WinBUGS model -------------------------------------------------------
poisson_model <- function() {
  for(i in 1:N) {  # Loop over each observation
    y[i] ~ dpois(mu[i])  # Specify that y[i] follows a Poisson distribution with mean mu[i]
    log(mu[i]) <- beta[1] + beta[2]*x1[i] + beta[3]*x2[i]  # Log-linear relationship for mu
  }
  for(j in 1:3) {  # Loop over the number of beta coefficients
    beta[j] ~ dnorm(0, 0.001)  # Vague normal priors for beta coefficients
  }
}

# Prepare data for WinBUGS ---------------------------------------------------
bugs_data <- list(
  N = n,
  y = y,
  x1 = x1,
  x2 = x2
)

# Set initial values ----------------------------------------------
inits <- function() {
  list(
    beta = rnorm(3, mean = 0, sd = 0.5)  # Random small initial values
  )
}

# Parameters to monitor ------------------------------------------------------
parameters <- c("beta")

# Run WinBUGS ----------------------------------------------------------------
results <- bugs(
  data = bugs_data,  # Data to be used in the model
  inits = inits,     # Initial values for the model parameters
  parameters.to.save = parameters,  # Parameters to be saved from the MCMC output
  model.file = poisson_model,  # The model file containing the WinBUGS model definition
  n.chains = 1,          # Number of MCMC chains to run
  n.iter = 10000,        # Total number of iterations per chain
  n.burnin = 5000,       # Number of iterations to discard as burn-in
  n.thin = 2,            # Thinning interval to reduce autocorrelation in samples
  debug = FALSE,         # Set to TRUE for debugging mode
  bugs.directory = "D:/WinBUGS14/",  # Path to the WinBUGS installation directory; modify as needed
  working.directory = getwd()  # Set the working directory to the current R working directory
)

# Analyze results ------------------------------------------------------------
REP =1
# Storage matrix for results
beta_estimates <- matrix(NA, nrow = REP, ncol = 3)
colnames(beta_estimates) <- c("beta0", "beta1", "beta2")
beta_estimates[sim, ] <- results$summary[1:3, "mean"]
# Calculate performance metrics ---------------------------------------------
bias <- colMeans(beta_estimates, na.rm = TRUE) - true_beta
empirical_se <- apply(beta_estimates, 2, sd, na.rm = TRUE)
rmse <- sqrt(colMeans((beta_estimates - 
                         matrix(true_beta, REP, 3, byrow = TRUE))^2, 
                      na.rm = TRUE))

# Create results table ------------------------------------------------------
results_table <- data.frame(
  Parameter = c("beta0", "beta1", "beta2"),
  True_Value = true_beta,
  Mean_Estimate = colMeans(beta_estimates, na.rm = TRUE),
  Bias = bias,
  SE = empirical_se,
  RMSE = rmse
)

# Print formatted results ---------------------------------------------------
cat("\nSimulation Results (REP =", REP, ")\n")
print(results_table, row.names = FALSE, digits = 4)

# Visualization -------------------------------------------------------------
# Extract posterior samples
posterior_samples <- as.data.frame(results$sims.matrix)
head(posterior_samples)

# Calculate Bayesian credible intervals
apply(posterior_samples[,1:3], 2, quantile, probs = c(0.025, 0.975))
par(mfrow = c(1,3))
for(i in 1:3) {
  plot(posterior_samples[,i], main = paste("MCMC chains of", colnames(beta_estimates)[i]),
       xlab = "Iteration", col = "skyblue", type="l")
}
