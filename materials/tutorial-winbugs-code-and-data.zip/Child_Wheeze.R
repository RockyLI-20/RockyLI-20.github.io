# Load Required Packages -----------------------------------------------------
library(mvtnorm)     # For multivariate normal distributions
library(R2WinBUGS)   # Bayesian inference using WinBUGS
library(geepack)     # Contains Ohio respiratory dataset

# Data Preparation -----------------------------------------------------------
# Load and restructure Ohio childhood respiratory data
data(ohio)
N <- 537    # Number of children
NT <- 4     # Number of time points

# Create matrices for longitudinal analysis:
age <- matrix(ohio$age, byrow = TRUE, ncol = NT)  # Age matrix (537x4)
smoke <- ohio$smoke[(0:536)*4 + 1]                # Maternal smoking status (baseline)
y <- matrix(ohio$resp, byrow = TRUE, ncol = NT)   # Respiratory status matrix (537x4)

# Model Specification --------------------------------------------------------
parameters <- c("beta", "sgm_u", "sgm_v")  # Parameters to monitor

# Initial Values for 2 Chains
init1 <- list(beta = rep(-1,3), psi_u = 1, psi_v = rep(1,NT))
init2 <- list(beta = rep(1,3), psi_u = 2, psi_v = rep(2,NT))
inits <- list(init1, init2)

# WinBUGS Data Input
data <- list(N = N, NT = NT, a = age, s = smoke, y = y)

# Define the generalized linear model function --------------------------------
glm_model <- function() {
    for(i in 1:N){
      for(t in 1:NT){
        eta[i,t]<-beta[1]+beta[2]*s[i]+beta[3]*a[i,t]+u[i]+v[i,t]
        p[i,t]<-exp(eta[i,t])/(1+exp(eta[i,t]))
        y[i,t]~dbern(p[i,t])
        v[i,t]~dnorm(0, psi_v[t])
      } # end of i
      
      u[i]~dnorm(0, psi_u)
      
    } # end of j
    
    # prior distribution
    psi_u~dgamma(9,4)
    sgm_u<-1/psi_u
    # psi_v~dgamma(9,4)
    # sgm_v<-1/psi_v
    for(j in 1:3){
      beta[j]~dnorm(0,0.01)
    } # end of j
    
    for(k in 1:NT){
      psi_v[k]~dgamma(9,4)
      sgm_v[k]<-1/psi_v[k]
    }
}
# Run Bayesian Model ---------------------------------------------------------
model <- bugs(data, inits, parameters,
              model.file = glm_model,
              n.chains = 2,        # Number of MCMC chains
              n.iter = 3000,       # Total iterations
              n.burnin = 1000,     # Burn-in period
              n.thin = 1,          # Thinning interval
              bugs.directory = "D:/WinBUGS14/",
              working.directory = getwd(),
              debug = FALSE)

# Extract Results ------------------------------------------------------------
Ebeta <- model$mean$beta           # Posterior means of fixed effects
SEbeta <- model$sd$beta            # Posterior SDs of fixed effects
Esgm_u <- model$mean$sgm_u         # Between-child SD
SEsgm_u <- model$sd$sgm_u          
Esgm_v <- model$mean$sgm_v         # Between-time SD
SEsgm_v <- model$sd$sgm_v


print(data.frame(
  Parameter = c("Intercept", "Maternal Smoking", "Age"),
  Estimate = round(Ebeta, 3),
  SE = round(SEbeta, 3)
))

print(data.frame(
  Parameter = c(as.character(expression(sigma[u])), 
  as.character(expression(sigma[v1])), 
  as.character(expression(sigma[v2])), 
  as.character(expression(sigma[v3])), 
  as.character(expression(sigma[v4]))),
  Estimate = round(c(Esgm_u,Esgm_v), 3),
  SE = round(c(SEsgm_u,SEsgm_v), 3)
))
