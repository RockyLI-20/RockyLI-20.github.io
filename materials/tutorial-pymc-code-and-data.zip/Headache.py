import os
from multiprocessing import freeze_support

# The following sentence must be putted before import pymc
os.environ["PATH"] = r"C:\msys64\mingw64\bin;" + os.environ.get("PATH", "")

import warnings
#warnings.filterwarnings("ignore", category=FutureWarning)

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pymc as pm
import arviz as az
from scipy.special import gammaln

"""
    Read Data
"""
df = pd.read_csv(
    "headache.txt",
    sep=r"\s+",
    header=None,
    names=["d", "y", "x", "NT_raw"],
    na_values=["NA"]
)

N = 27
Tmax = 5

"""
    Reshape Data
"""
x_mat = df["x"].to_numpy().reshape(N, Tmax)
d_mat = df["d"].to_numpy().reshape(N, Tmax)
y_mat = df["y"].to_numpy().reshape(N, Tmax)

"""
    Calculate NT
"""
NT = np.sum(~np.isnan(y_mat), axis=1)
print("NT =", NT)

mask = ~np.isnan(y_mat) & ~np.isnan(d_mat)

subj_idx, time_idx = np.where(mask)

x_obs = x_mat[mask].astype(float)
d_obs = d_mat[mask].astype(float)
y_obs = y_mat[mask].astype(int)

"""
    Establish GLMM Model
"""
with pm.Model() as glmm_model:
    # Prepare data
    x_data = pm.Data("x_data", x_obs)
    d_data = pm.Data("d_data", d_obs)
    subj_data = pm.Data("subj_data", subj_idx)

    # fixed effects and prior
    beta0 = pm.Normal("beta0", mu=0, sigma=5)
    beta1 = pm.Normal("beta1", mu=0, sigma=5)

    # random intercept
    sigma_u = pm.HalfNormal("sigma_u", sigma=2)
    u = pm.Normal("u", mu=0, sigma=sigma_u, shape=N)

    # linear predictor with offset
    eta = beta0 + beta1 * x_data + u[subj_data] + pm.math.log(d_data)
    mu = pm.Deterministic("mu", pm.math.exp(eta))

    # likelihood
    y_like = pm.Poisson("y_like", mu=mu, observed=y_obs)

    idata_glmm = pm.sample(
        draws=2000,
        tune=2000,
        chains=4,
        cores=1,
        target_accept=0.9,
        random_seed=666,
        return_inferencedata=True
    )

    pm.compute_log_likelihood(idata_glmm, model=glmm_model)
    ppc = pm.sample_posterior_predictive(idata_glmm, random_seed=666)
    idata_glmm.extend(ppc)

"""
    View the summary of the model
"""
print(
    az.summary(
        idata_glmm,
        var_names=["beta0", "beta1", "sigma_u"],
        hdi_prob=0.95,
        round_to=3
    )
)

"""
    Model Diagnostics
"""
az.plot_trace(idata_glmm, var_names=["beta0", "beta1", "sigma_u"])
plt.tight_layout()
plt.show()

az.plot_rank(idata_glmm, var_names=["beta0", "beta1", "sigma_u"])
plt.tight_layout()
plt.show()

az.plot_ppc(idata_glmm, var_names=["y_like"])
plt.tight_layout()
plt.show()

az.plot_energy(idata_glmm)
plt.tight_layout()
plt.show()

print("\nR-hat")
print(az.rhat(idata_glmm, var_names=["beta0", "beta1", "sigma_u"]))

print("\nESS")
print(az.ess(idata_glmm, var_names=["beta0", "beta1", "sigma_u"]))

print("\nBFMI")
print(az.bfmi(idata_glmm))

n_div = int(idata_glmm.sample_stats["diverging"].sum().values)
print(f"\nNumber of divergences = {n_div}")



"""
    Establish GLM model
"""
with pm.Model() as glm_model:
    # Prepare data
    x_data = pm.Data("x_data", x_obs)
    d_data = pm.Data("d_data", d_obs)

    # fixed effects and prior
    beta0 = pm.Normal("beta0", mu=0, sigma=5)
    beta1 = pm.Normal("beta1", mu=0, sigma=5)

    # linear predictor with offset
    eta = beta0 + beta1 * x_data + pm.math.log(d_data)
    mu = pm.Deterministic("mu", pm.math.exp(eta))

    # likelihood
    y_like = pm.Poisson("y_like", mu=mu, observed=y_obs)

    idata_glm = pm.sample(
        draws=2000,
        tune=2000,
        chains=4,
        cores=1,
        target_accept=0.9,
        random_seed=666,
        return_inferencedata=True
    )

    ppc = pm.sample_posterior_predictive(idata_glm, random_seed=666)
    idata_glm.extend(ppc)
    pm.compute_log_likelihood(idata_glm, model=glm_model)

    """
        View the summary of the model
    """
    print(
        az.summary(
            idata_glm,
            var_names=["beta0", "beta1"],
            hdi_prob=0.95,
            round_to=3
        )
    )

    """
        Model Diagnostics
    """
    az.plot_trace(idata_glm, var_names=["beta0", "beta1"])
    plt.tight_layout()
    plt.show()

    az.plot_rank(idata_glm, var_names=["beta0", "beta1"])
    plt.tight_layout()
    plt.show()

    az.plot_ppc(idata_glm, var_names=["y_like"])
    plt.tight_layout()
    plt.show()

    az.plot_energy(idata_glm)
    plt.tight_layout()
    plt.show()

    print("\nR-hat")
    print(az.rhat(idata_glm, var_names=["beta0", "beta1"]))

    print("\nESS")
    print(az.ess(idata_glm, var_names=["beta0", "beta1"]))

    print("\nBFMI")
    print(az.bfmi(idata_glm))

    n_div = int(idata_glm.sample_stats["diverging"].sum().values)
    print(f"\nNumber of divergences = {n_div}")


"""
    Model Comparison
"""

"===== The following three functions are used to calculate DIC of model ====="

def poisson_deviance(y, mu):
    loglik = y * np.log(mu) - mu - gammaln(y + 1)
    return -2 * np.sum(loglik)


def dic_glm(idata, x_obs, d_obs, y_obs):
    beta0_bar = idata.posterior["beta0"].mean().item()
    beta1_bar = idata.posterior["beta1"].mean().item()

    mu_bar = np.exp(beta0_bar + beta1_bar * x_obs + np.log(d_obs))

    ll = idata.log_likelihood["y_like"]
    obs_dims = [d for d in ll.dims if d not in ("chain", "draw")]
    D_bar = (-2 * ll.sum(dim=obs_dims)).mean().item()
    D_hat = poisson_deviance(y_obs, mu_bar)

    return 2 * D_bar - D_hat


def dic_glmm(idata, x_obs, d_obs, y_obs, subj_idx):
    beta0_bar = idata.posterior["beta0"].mean().item()
    beta1_bar = idata.posterior["beta1"].mean().item()
    u_bar = idata.posterior["u"].mean(dim=("chain", "draw")).values

    mu_bar = np.exp(beta0_bar + beta1_bar * x_obs + u_bar[subj_idx] + np.log(d_obs))

    ll = idata.log_likelihood["y_like"]
    obs_dims = [d for d in ll.dims if d not in ("chain", "draw")]
    D_bar = (-2 * ll.sum(dim=obs_dims)).mean().item()
    D_hat = poisson_deviance(y_obs, mu_bar)

    return 2 * D_bar - D_hat

print("\n===== LOO comparison =====")
cmp_loo = az.compare(
    {"GLMM": idata_glmm, "GLM": idata_glm},
    ic="loo",
    method="stacking"
)
print(cmp_loo)

print("\n===== WAIC comparison =====")
cmp_waic = az.compare(
    {"GLMM": idata_glmm, "GLM": idata_glm},
    ic="waic",
    method="stacking"
)
print(cmp_waic)

"""  ===== plot_compare (LOO) =====  """
az.plot_compare(cmp_loo)
plt.tight_layout()
plt.show()

print("\n===== DIC Comparison=====")
dic_glmm = dic_glmm(idata_glmm, x_obs, d_obs, y_obs, subj_idx)
dic_glm = dic_glm(idata_glm, x_obs, d_obs, y_obs)

print(f"GLMM DIC ≈ {dic_glmm:.3f}")
print(f"GLM  DIC ≈ {dic_glm:.3f}")