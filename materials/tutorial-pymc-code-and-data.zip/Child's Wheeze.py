import os
from multiprocessing import freeze_support

# The following sentence must be putted before import pymc
os.environ["PATH"] = r"C:\msys64\mingw64\bin;" + os.environ.get("PATH", "")

import warnings
#warnings.filterwarnings("ignore", category=FutureWarning)

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pymc as pm
import arviz as az

"""
    Read Data
"""
df = pd.read_csv("ohio.csv")
df = df.drop(columns=["rownames"])

# Child index
child_codes, child_uniques = pd.factorize(df["id"])
n_child = len(child_uniques)

# visit index: age -2,-1,0,1 -> 0,1,2,3
age_order = [-2, -1, 0, 1]
visit_map = {a: i for i, a in enumerate(age_order)}
visit_idx = df["age"].map(visit_map).to_numpy()

# observed variables
y = df["resp"].to_numpy()
smoke = df["smoke"].to_numpy()
age = df["age"].to_numpy()

coords = {
    "obs": np.arange(len(df)),
    "child": np.arange(n_child),
    "visit": np.arange(4),
}

"""
    Establish GLMM model
"""
with pm.Model(coords=coords) as glmm_model:
    # prepare data
    smoke_data = pm.Data("smoke_data", smoke, dims="obs")
    age_data = pm.Data("age_data", age, dims="obs")
    child_data = pm.Data("child_data", child_codes, dims="obs")
    visit_data = pm.Data("visit_data", visit_idx, dims="obs")

    # fixed effects priors
    beta0 = pm.Normal("beta0", mu=0, sigma=5)
    beta1 = pm.Normal("beta1", mu=0, sigma=5)
    beta2 = pm.Normal("beta2", mu=0, sigma=5)

    # random effect
    sigma_u = pm.HalfNormal("sigma_u", sigma=1.0)
    u_raw = pm.Normal("u_raw", mu=0, sigma=1, dims="child")
    u = pm.Deterministic("u", sigma_u * u_raw, dims="child")

    # child-specific visit effects
    sigma_v = pm.HalfNormal("sigma_v", sigma=1.0, dims="visit")
    v_raw = pm.Normal("v_raw", mu=0, sigma=1, dims=("child", "visit"))
    v = pm.Deterministic("v", v_raw * sigma_v, dims=("child", "visit"))

    # linear predictor
    eta = (beta0 + beta1 * smoke_data + beta2 * age_data + u[child_data] + v[child_data, visit_data])

    # Bernoulli likelihood
    y_like = pm.Bernoulli("y_like", logit_p=eta, observed=y, dims="obs")

    # posterior sampling
    idata = pm.sample(
        draws=2000,
        tune=2000,
        chains=4,
        cores=1,
        target_accept=0.95,
        random_seed=666,
        return_inferencedata=True
    )

    # posterior predictive
    ppc = pm.sample_posterior_predictive(idata, random_seed=666)
    idata.extend(pm.sample_posterior_predictive(idata, random_seed=666))

    """
        View the Summary of model
    """
    print(
        az.summary(
            idata,
            var_names=["beta0", "beta1", "beta2", "sigma_u", "sigma_v"],
            hdi_prob=0.95,
            round_to=3
        )
    )

    # odds ratio for smoking
    beta1_draws = idata.posterior["beta1"].values.reshape(-1)
    or_smoke = np.exp(beta1_draws)
    print("\nSmoking OR:")
    print(f"Posterior mean OR = {or_smoke.mean():.3f}")
    print(f"95% CrI = ({np.quantile(or_smoke, 0.025):.3f}, "
          f"{np.quantile(or_smoke, 0.975):.3f})")

    """
        Model Diagnostics
    """
    az.plot_trace(idata, var_names=["beta0", "beta1", "beta2", "sigma_u"])
    plt.tight_layout()
    plt.show()

    az.plot_rank(idata, var_names=["beta0", "beta1", "beta2", "sigma_u"])
    plt.tight_layout()
    plt.show()

    az.plot_ppc(idata, var_names=["y_like"])
    plt.tight_layout()
    plt.show()

    az.plot_energy(idata)
    plt.tight_layout()
    plt.show()

    print("\nR-hat")
    print(az.rhat(idata, var_names=["beta0", "beta1", "beta2", "sigma_u", "sigma_v"]))

    print("\nESS")
    print(az.ess(idata, var_names=["beta0", "beta1", "beta2", "sigma_u", "sigma_v"]))

    print("\nBFMI")
    print(az.bfmi(idata))

    n_div = int(idata.sample_stats["diverging"].sum().values)
    print(f"\nNumber of divergences = {n_div}")


