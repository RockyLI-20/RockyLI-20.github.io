import os
from multiprocessing import freeze_support

# The following sentence must be putted before import pymc
os.environ["PATH"] = r"C:\msys64\mingw64\bin;" + os.environ.get("PATH", "")

import warnings
#warnings.filterwarnings("ignore", category=FutureWarning)

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pymc as pm
import arviz as az

"""
    Data Generator
    Model Specification: 
    1. y ~ poisson(mu)
    2. log(mu) = beta0 + beta1 * x1 + beta2 * x2
"""
def main():
    rng = np.random.default_rng(666) # random seed
    n = 500 # sample size
    beta_true = np.array([0.5, 1.0, -1.0]) # true value of parameter

    x1 = rng.normal(0, 1, n) # generate x1
    x2 = rng.uniform(0, 1, n) # generate x2

    # Calculate linear predictor and y
    linear_predictor = beta_true[0] + beta_true[1] * x1 + beta_true[2] * x2
    mu = np.exp(linear_predictor)
    y = rng.poisson(lam=mu)

    # Construct data as a data frame
    df = pd.DataFrame({
        "y": y,
        "x1": x1,
        "x2": x2
    })

    """
    Construct Model using PyMC
    """
    with pm.Model() as pois_glm:
        x1_data = pm.Data("x1_data", df["x1"].values)
        x2_data = pm.Data("x2_data", df["x2"].values)

        # Set prior
        """ 
            Here we choose normal distribution(with mean zero and large variance) as the prior of parameters 
            In practise you can adjust the prior distribution according to different cases 
        """
        beta0 = pm.Normal("beta0", mu=0, sigma=10)
        beta1 = pm.Normal("beta1", mu=0, sigma=5)
        beta2 = pm.Normal("beta2", mu=0, sigma=5)

        # Linear predictor and link function
        eta = beta0 + beta1 * x1_data + beta2 * x2_data
        mu_model = pm.Deterministic("mu", pm.math.exp(eta))

        y_obs = pm.Poisson("y_obs", mu=mu_model, observed=df["y"].values)

        """
            Interpretation of parameters: 
            1. draws: The number of posterior samples kept after tuning for each chain. 
            2. tune: The number of warm-up iterations per chain. 
            3. chains: The number of independent Markov chains to run. 
            4. cores: The maximum number of chains to run in parallel. 
            5. target_accept: The target acceptance rate for NUTS. 
            A higher target_accept often makes sampling more conservative and more stable 
            6. return_inferencedata: Return an ArviZ InferenceData object instead of the legacy MultiTrace.
        """
        idata = pm.sample(
            draws=2000,
            tune=2000,
            chains=4,
            cores=4,
            target_accept=0.90,
            random_seed=666,
            return_inferencedata=True
        )

        ppc = pm.sample_posterior_predictive(idata, random_seed=666)
        idata.extend(ppc)

    """
        View the summary of model
    """
    summary = az.summary(
        idata,
        var_names=["beta0", "beta1", "beta2"],
        hdi_prob=0.95,
        round_to=3
    )
    print(summary)

    print("\nTrue values:")
    print({"beta0": 0.5, "beta1": 1.0, "beta2": -1.0})

    """
        Diagnostic plots
    """

    """
        Trace Plot: shows whether the chains mix well and stabilize in the same region.
        1. Left hand side: posterior distribution
        2. Right hand side: sampling traceplot
    """
    az.plot_trace(idata, var_names=["beta0", "beta1", "beta2"])
    plt.tight_layout()
    plt.show()

    """
        Rank plot: checks whether different chains are sampling from the same posterior distribution.
    """
    az.plot_rank(idata, var_names=["beta0", "beta1", "beta2"])
    plt.tight_layout()
    plt.show()

    """
        PPC plot: checks whether the model can generate data similar to the observed data.
    """
    az.plot_ppc(idata, var_names=["y_obs"])
    plt.tight_layout()
    plt.show()

    """
        Energy plot: diagnoses whether HMC/NUTS is exploring the posterior geometry efficiently.
    """
    az.plot_energy(idata)
    plt.tight_layout()
    plt.show()

    """
    Numeric diagnostics
    """

    """
        R-hat: Compare the fluctuation in the chain and difference among chains
        If R-hat is close to 1, that means the chain converge
    """
    print("\nR-hat")
    print(az.rhat(idata, var_names=["beta0", "beta1", "beta2"]))

    """
        ESS: which means Effective Sample Size
        The larger the ESS, the more stable the posterior estimate
    """
    print("\nESS")
    print(az.ess(idata, var_names=["beta0", "beta1", "beta2"]))

    """
        BFMI indicates whether the sampler thoroughly explored the energy level
        If BFMI is low, the geometry structure of posterior may not good
    """
    print("\nBFMI")
    print(az.bfmi(idata))

    """
        Number of divergence: Are there any NUTS regions where sampling has failed or is unreliable
        The ideal value is 0
    """
    n_div = int(idata.sample_stats["diverging"].sum().values)
    print(f"\nNumber of divergences = {n_div}")


if __name__ == "__main__":
    freeze_support()
    main()